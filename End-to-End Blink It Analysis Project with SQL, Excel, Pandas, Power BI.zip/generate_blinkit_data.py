import pandas as pd
import numpy as np
import random

# Set seed for reproducibility
np.random.seed(42)

# Define parameters
num_rows = 8523
item_types = ['Fruits and Vegetables', 'Snack Foods', 'Household', 'Frozen Foods', 'Dairy', 'Canned', 'Baking Goods', 'Health and Hygiene', 'Soft Drinks', 'Meat', 'Breads', 'Hard Drinks', 'Others', 'Starchy Foods', 'Breakfast', 'Seafood']
outlet_sizes = ['Small', 'Medium', 'High']
location_types = ['Tier 1', 'Tier 2', 'Tier 3']
outlet_types = ['Supermarket Type1', 'Supermarket Type2', 'Supermarket Type3', 'Grocery Store']
fat_contents = ['Low Fat', 'Regular']

# Generate data
data = {
    'Item_Identifier': ['FD' + str(random.randint(1000, 9999)) for _ in range(num_rows)],
    'Item_Weight': np.round(np.random.uniform(4.5, 21.5, num_rows), 2),
    'Item_Fat_Content': [random.choice(fat_contents) for _ in range(num_rows)],
    'Item_Visibility': np.round(np.random.uniform(0.006, 0.32, num_rows), 4),
    'Item_Type': [random.choice(item_types) for _ in range(num_rows)],
    'Item_MRP': np.round(np.random.uniform(31, 266, num_rows), 2),
    'Outlet_Identifier': ['OUT0' + str(random.randint(10, 49)) for _ in range(num_rows)],
    'Outlet_Establishment_Year': [random.randint(2011, 2024) for _ in range(num_rows)],
    'Outlet_Size': [random.choice(outlet_sizes) for _ in range(num_rows)],
    'Outlet_Location_Type': [random.choice(location_types) for _ in range(num_rows)],
    'Outlet_Type': [random.choice(outlet_types) for _ in range(num_rows)],
}

# Calculate Sales (simulated logic: Sales = MRP * random_quantity * visibility_factor)
# In the standard dataset, Item_Outlet_Sales is a target variable.
# We'll generate it based on some realistic factors.
df = pd.DataFrame(data)
df['Item_Outlet_Sales'] = np.round(df['Item_MRP'] * np.random.uniform(5, 50, num_rows) * (1 + df['Item_Visibility']), 2)

# Add some nulls to simulate real-world data for cleaning phase
df.loc[df.sample(frac=0.05).index, 'Item_Weight'] = np.nan
df.loc[df.sample(frac=0.03).index, 'Outlet_Size'] = np.nan

# Save to CSV
df.to_csv('blinkit_sales_data.csv', index=False)
print("Dataset generated successfully: blinkit_sales_data.csv")
