# Blinkit Data Analysis Project Report

## 1. Introduction
This report details an end-to-end data analysis project focused on Blinkit, a prominent quick-commerce platform. The objective is to analyze sales performance, customer satisfaction, and inventory distribution to derive actionable insights for business optimization. The project leverages a simulated dataset and employs a comprehensive analytical toolkit including SQL for data querying, Pandas (Python) for exploratory data analysis and manipulation, and Python-based visualization libraries (Matplotlib, Seaborn) to emulate Power BI-style dashboards.

## 2. Project Scope and Methodology

### 2.1 Key Performance Indicators (KPIs)
To assess Blinkit's operational efficiency and market performance, the following KPIs were identified:
- **Total Sales**: Aggregate revenue generated.
- **Average Sales**: Mean revenue per transaction.
- **Number of Items**: Total quantity of products sold.
- **Average Rating**: Mean customer satisfaction score (though not directly generated in this dataset, it's a crucial KPI for such businesses).

### 2.2 Analysis Dimensions
The analysis explores various dimensions to provide a holistic view:
- **Item Type**: Product categories such as Fruits and Vegetables, Snacks, Household, etc.
- **Outlet Type**: Different store formats like Supermarket Type1, Grocery Store.
- **Outlet Size**: Store capacities (Small, Medium, High).
- **Location Type**: Geographical distribution across Tier 1, Tier 2, and Tier 3 cities.
- **Fat Content**: Product attributes like Low Fat vs. Regular.

### 2.3 Methodology Overview
The project followed a structured approach:
1.  **Data Generation**: A synthetic dataset mirroring Blinkit's operational data was created using Python, incorporating realistic distributions and missing values for a robust analysis scenario.
2.  **SQL Database Setup and Analysis**: The generated data was loaded into an SQLite database. SQL queries were then executed to extract key metrics and aggregated insights, forming the foundation for further analysis.
3.  **Pandas EDA and Excel Export**: Python's Pandas library was utilized for in-depth Exploratory Data Analysis (EDA), including data cleaning (handling missing values, standardizing categories), descriptive statistics, and correlation analysis. Key findings were exported to an Excel workbook for detailed review.
4.  **Visualization**: Power BI-style dashboards were simulated using Matplotlib and Seaborn in Python to visualize trends and patterns identified during the analysis phases.

## 3. SQL Analysis Results
SQL queries were executed to derive foundational insights into the dataset. The key findings are summarized below:

### 3.1 Overall KPIs
| Metric        | Value         |
|---------------|---------------|
| Total Sales   | 40,713,446.72 |
| Average Sales | 4,776.89      |
| Total Items   | 8,523         |

### 3.2 Sales by Item Type
Sales performance varies significantly across different item types. The top-performing categories are:

| Item Type             | Total Sales   | Item Count |
|-----------------------|---------------|------------|
| Fruits and Vegetables | 2,873,575.37  | 564        |
| Baking Goods          | 2,707,333.67  | 547        |
| Hard Drinks           | 2,694,983.38  | 551        |
| Breakfast             | 2,663,808.82  | 551        |
| Household             | 2,634,503.82  | 551        |

### 3.3 Sales by Outlet Type
Different outlet types contribute differently to overall sales:

| Outlet Type       | Total Sales   | Average Sales |
|-------------------|---------------|---------------|
| Supermarket Type3 | 10,328,053.70 | 4,739.81      |
| Supermarket Type2 | 10,322,862.80 | 4,768.07      |
| Grocery Store     | 10,067,567.89 | 4,803.23      |
| Supermarket Type1 | 9,994,962.33  | 4,798.35      |

### 3.4 Sales by Location Tier
Sales distribution across different city tiers shows relatively balanced performance:

| Location Type | Total Sales   |
|---------------|---------------|
| Tier 1        | 13,668,859.83 |
| Tier 2        | 13,521,868.78 |
| Tier 3        | 13,522,718.11 |

### 3.5 Top 5 Items by Sales
| Item Identifier | Item Type     | Total Sales |
|-----------------|---------------|-------------|
| FD1099          | Starchy Foods | 45,932.07   |
| FD2803          | Dairy         | 37,951.63   |
| FD5846          | Meat          | 34,161.86   |
| FD4709          | Soft Drinks   | 34,155.68   |
| FD7254          | Seafood       | 34,150.04   |

## 4. Pandas EDA and Data Preparation
The raw data underwent cleaning and exploratory analysis using Pandas. Missing values in `Item_Weight` were imputed with the mean, and `Outlet_Size` missing values were filled with 'Medium'. `Item_Fat_Content` was standardized to 'Low Fat' and 'Regular' for consistency.

### 4.1 Summary Statistics
- **Total Sales**: 40,713,446.72
- **Average Sales**: 4,776.89
- **Median Sales**: 4,776.89
- **Max Sales**: 26,599.98
- **Total Items**: 8,523

### 4.2 Sales by Category and Fat Content
A pivot table analysis revealed sales distribution across item types and fat content, highlighting product performance based on these attributes. This data is available in the `blinkit_analysis_report.xlsx` file.

### 4.3 Correlation Analysis
Correlation analysis between numerical features (e.g., `Item_Weight`, `Item_Visibility`, `Item_MRP`, `Item_Outlet_Sales`) was performed to understand relationships within the data. The correlation matrix is available in the `blinkit_analysis_report.xlsx` file.

## 5. Dashboard Analysis (Visualizations)
To provide a clear and intuitive understanding of the data, several visualizations were created, mimicking a Power BI dashboard. These charts highlight key trends and patterns.

### 5.1 Total Sales by Item Type
![Total Sales by Item Type](https://private-us-east-1.manuscdn.com/sessionFile/GA8OBiNZiGsCSmC9aKkSZ5/sandbox/cQiFHmoB9StX8QxnxQZWbp-images_1781680671022_na1fn_L2hvbWUvdWJ1bnR1L3NhbGVzX2J5X2l0ZW1fdHlwZQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR0E4T0JpTlppR3NDU21DOWFLa1NaNS9zYW5kYm94L2NRaUZIbW9COVN0WDhReG54UVpXYnAtaW1hZ2VzXzE3ODE2ODA2NzEwMjJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzTmhiR1Z6WDJKNVgybDBaVzFmZEhsd1pRLnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=WU03ebYFsuQ3bJ3fyw-Fn6TZ-Obqk-NGzDFP~28ILiLSp-c8LGNEOjcIQEzLJjzQ5rk8kkGcz4EMuShqnYoyjkXd660q8h3hgGnO2vNkzIQolfFEkn3cVOaG13DVX-pqRMt4Mk3uUJBqBkGONmx2SZSA8OOGRetIg24fCAOQNGqxl0F6eqcX7P6UnnmXV~JwYs3j522xxzuMxjz52wfSfEDVWwXr5sYkF4pZMJYM8K3Q9Zu~Ap~eiz77cy5GTN06aQUgyFPWh9gZ0vXr4FptUbiY9g-Fz23XjhUil8Gf71K1QQPMh6ZyP9oGZidfW5FxD19x64sMYWnk~j4GQoBokw__)
This bar chart illustrates the sales contribution of each product category, identifying top-selling item types.

### 5.2 Sales Distribution by Outlet Type
![Sales Distribution by Outlet Type](https://private-us-east-1.manuscdn.com/sessionFile/GA8OBiNZiGsCSmC9aKkSZ5/sandbox/cQiFHmoB9StX8QxnxQZWbp-images_1781680671022_na1fn_L2hvbWUvdWJ1bnR1L3NhbGVzX2J5X291dGxldF90eXBl.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR0E4T0JpTlppR3NDU21DOWFLa1NaNS9zYW5kYm94L2NRaUZIbW9COVN0WDhReG54UVpXYnAtaW1hZ2VzXzE3ODE2ODA2NzEwMjJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzTmhiR1Z6WDJKNVgyOTFkR3hsZEY5MGVYQmwucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=BMBnV2xXEvAKwsg65P4XDECWj4zg2jb1tiPU-EmvpU9xJ3kYrSLy139uhMr-ssgZOBCdV3~95gCGaWPK6XtjXhprY7DiCUx7LFqAnrby9sXuak6Zn3Yvwmn~pHofp4YjofaU1zcVR3ahi3bx9T4RLsnNgL28T5FciiMwOjtwblpuzcXfK-sN4q1A3svhE-WwCFYcvCK8Xtb7exmHskkidlS5xJpnkkbdFa19oLT~Uj7cBAAVeuTvA801ACeYALidOmpLrr0fqSg~N78dYKXW4LpIDbrbxvGL3KTpMFprwCzGTPWprDCBRDcaGs0CWcKh~q19E5k0NB~w8qUhLDUxgw__)
This pie chart shows the proportional sales generated by different outlet types, indicating which store formats are most lucrative.

### 5.3 Sales by Location Tier
![Sales by Location Tier](https://private-us-east-1.manuscdn.com/sessionFile/GA8OBiNZiGsCSmC9aKkSZ5/sandbox/cQiFHmoB9StX8QxnxQZWbp-images_1781680671022_na1fn_L2hvbWUvdWJ1bnR1L3NhbGVzX2J5X2xvY2F0aW9u.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR0E4T0JpTlppR3NDU21DOWFLa1NaNS9zYW5kYm94L2NRaUZIbW9COVN0WDhReG54UVpXYnAtaW1hZ2VzXzE3ODE2ODA2NzEwMjJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzTmhiR1Z6WDJKNVgyeHZZMkYwYVc5dS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=pYeO9S0ou0t~N-ntosV8yPcuehY65X50xXrLkPShBZYw8EOaFxUe-PKiH~cpBvu1-57I9LcAd7ccRah~e3bdkgMFa4Xn01dnHh9xjCeei8a7kW6S3SzmkDqMRISdWZudZ4EL-GNgYzTiJOgsnhMzc7vCdnRRAj6rNTC6ppDLP4~FkW87YnwzNj8xuZ4QGnitx4O2sFhQej~8G1MDyP-RtbEOTSwt60uChgFc-mBsyRZ6H7A6EBtngvczLZ3LsTBixhyc-tme37s6xBM11ODQqnYFnNKN1URnsB-bjM2kUCGaRFGsR1acvhbtTwVtzZnpn4~AKBcTLDsZndWlmD6Tng__)
This donut chart visualizes the sales distribution across various city tiers, helping to understand regional performance.

### 5.4 Product Distribution by Fat Content
![Product Distribution by Fat Content](https://private-us-east-1.manuscdn.com/sessionFile/GA8OBiNZiGsCSmC9aKkSZ5/sandbox/cQiFHmoB9StX8QxnxQZWbp-images_1781680671022_na1fn_L2hvbWUvdWJ1bnR1L2ZhdF9jb250ZW50X2Rpc3RyaWJ1dGlvbg.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR0E4T0JpTlppR3NDU21DOWFLa1NaNS9zYW5kYm94L2NRaUZIbW9COVN0WDhReG54UVpXYnAtaW1hZ2VzXzE3ODE2ODA2NzEwMjJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyWmhkRjlqYjI1MFpXNTBYMlJwYzNSeWFXSjFkR2x2YmcucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=cAjlQQh-oT65urgVWq6aPx6ptYk91qEpRc-mvWbbXM5SHlEIg8BA~wHV3jQP4cinAw9SyD-mpby98Llq7D~wJu1I9FEGpwehFKp6vzFxDwSu~cPJPOvT6zft4pKQgZwYiFz6~pjqz92hM1FQSleVLcm-w4pAURoJmlAsnFS12w~bcr3cB0u7~RExqqpRR3dllqSNcGn202sh6YwXK8Nyyr~CkA7rnS9jOyD5HxZJVZSxwZZgsQe6gMLFsYerSne-96GterdSSuPYyTwQNdNE7YDq3vvkLrfu6Y1AkpjBh8xL8L6lzOQSS5dcv48P4-tPzTeYSMvUoQFtmtGbGrXuMA__)
This count plot displays the distribution of products based on their fat content, offering insights into inventory composition and customer preferences.

## 6. Conclusion and Recommendations

### 6.1 Conclusion
This project successfully demonstrated an end-to-end data analysis workflow for Blinkit. Key insights were extracted regarding sales performance across different item types, outlet formats, and geographical locations. The data cleaning and EDA phases ensured data quality and revealed underlying patterns, while the visualizations provided an accessible summary of the findings.

### 6.2 Recommendations
Based on the analysis, the following recommendations are proposed:

1.  **Focus on High-Performing Item Types**: Continue to optimize inventory and marketing efforts for 'Fruits and Vegetables', 'Baking Goods', and 'Hard Drinks', as these categories consistently show high sales.
2.  **Evaluate Outlet Performance**: Investigate the operational strategies of 'Supermarket Type3' and 'Supermarket Type2' to understand their higher sales generation and potentially replicate best practices across other outlet types.
3.  **Regional Strategy**: While sales are relatively balanced across location tiers, a deeper dive into specific cities within each tier could uncover localized opportunities or challenges.
4.  **Fat Content Preference**: Further analyze customer purchasing behavior related to 'Low Fat' vs. 'Regular' products to tailor product offerings and promotions effectively.
5.  **Inventory Optimization**: Use the top-selling item data to ensure adequate stock levels and prevent out-of-stock situations for high-demand products.

## References
[1] Kaggle. (n.d.). *Blinkit Sales Dataset*. Retrieved from [https://www.kaggle.com/datasets/akxiit/blinkit-sales-dataset](https://www.kaggle.com/datasets/akxiit/blinkit-sales-dataset)
[2] Brineweb. (2026). *Blinkit Business Model & Revenue Model Explained (2026)*. Retrieved from [https://www.brineweb.com/blog/blinkit-business-model-revenue-model-explained-2026](https://www.brineweb.com/blog/blinkit-business-model-revenue-model-explained-2026)
