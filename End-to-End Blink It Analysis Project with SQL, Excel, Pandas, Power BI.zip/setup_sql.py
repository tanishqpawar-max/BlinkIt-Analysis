import sqlite3
import pandas as pd

# Load the generated CSV
df = pd.read_csv('blinkit_sales_data.csv')

# Connect to SQLite database
conn = sqlite3.connect('blinkit_analysis.db')
cursor = conn.cursor()

# Create table
df.to_sql('sales_data', conn, if_exists='replace', index=False)

# Verify table creation
cursor.execute("SELECT COUNT(*) FROM sales_data")
count = cursor.fetchone()[0]
print(f"Table 'sales_data' created with {count} records.")

conn.close()
