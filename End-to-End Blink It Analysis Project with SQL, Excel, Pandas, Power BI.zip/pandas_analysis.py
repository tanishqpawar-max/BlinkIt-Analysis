import pandas as pd
import numpy as np

# Load data
df = pd.read_csv('blinkit_sales_data.csv')

# 1. Data Cleaning
# Handle missing values
df['Item_Weight'] = df['Item_Weight'].fillna(df['Item_Weight'].mean())
df['Outlet_Size'] = df['Outlet_Size'].fillna('Medium')

# Standardize Fat Content
df['Item_Fat_Content'] = df['Item_Fat_Content'].replace({'LF': 'Low Fat', 'low fat': 'Low Fat', 'reg': 'Regular'})

# 2. Exploratory Data Analysis (EDA)
eda_summary = {
    'Total Sales': df['Item_Outlet_Sales'].sum(),
    'Average Sales': df['Item_Outlet_Sales'].mean(),
    'Median Sales': df['Item_Outlet_Sales'].median(),
    'Max Sales': df['Item_Outlet_Sales'].max(),
    'Total Items': df.shape[0]
}

# Sales by Category and Fat Content
pivot_table = df.pivot_table(index='Item_Type', columns='Item_Fat_Content', values='Item_Outlet_Sales', aggfunc='sum')

# 3. Correlation Analysis (Numeric only)
numeric_df = df.select_dtypes(include=[np.number])
correlation = numeric_df.corr()

# 4. Save to Excel with multiple sheets
with pd.ExcelWriter('blinkit_analysis_report.xlsx') as writer:
    df.to_excel(writer, sheet_name='Cleaned Data', index=False)
    pd.DataFrame([eda_summary]).to_excel(writer, sheet_name='Summary Metrics', index=False)
    pivot_table.to_excel(writer, sheet_name='Sales by Category')
    correlation.to_excel(writer, sheet_name='Correlations')

print("Pandas EDA completed and Excel report generated: blinkit_analysis_report.xlsx")
