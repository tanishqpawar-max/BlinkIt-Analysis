import sqlite3
import pandas as pd

def run_query(query, title):
    conn = sqlite3.connect('blinkit_analysis.db')
    result = pd.read_sql_query(query, conn)
    conn.close()
    print(f"\n--- {title} ---")
    print(result)
    return result

# 1. Total Sales and Key Metrics
kpi_query = """
SELECT 
    ROUND(SUM(Item_Outlet_Sales), 2) as Total_Sales,
    ROUND(AVG(Item_Outlet_Sales), 2) as Avg_Sales,
    COUNT(*) as Total_Items
FROM sales_data;
"""
run_query(kpi_query, "Overall KPIs")

# 2. Sales by Item Type
item_type_query = """
SELECT 
    Item_Type, 
    ROUND(SUM(Item_Outlet_Sales), 2) as Total_Sales,
    COUNT(*) as Item_Count
FROM sales_data
GROUP BY Item_Type
ORDER BY Total_Sales DESC;
"""
run_query(item_type_query, "Sales by Item Type")

# 3. Sales by Outlet Type
outlet_type_query = """
SELECT 
    Outlet_Type,
    ROUND(SUM(Item_Outlet_Sales), 2) as Total_Sales,
    ROUND(AVG(Item_Outlet_Sales), 2) as Avg_Sales
FROM sales_data
GROUP BY Outlet_Type
ORDER BY Total_Sales DESC;
"""
run_query(outlet_type_query, "Sales by Outlet Type")

# 4. Sales by Location Tier
location_query = """
SELECT 
    Outlet_Location_Type,
    ROUND(SUM(Item_Outlet_Sales), 2) as Total_Sales
FROM sales_data
GROUP BY Outlet_Location_Type;
"""
run_query(location_query, "Sales by Location Tier")

# 5. Top 5 Items by Sales
top_items_query = """
SELECT 
    Item_Identifier,
    Item_Type,
    ROUND(SUM(Item_Outlet_Sales), 2) as Total_Sales
FROM sales_data
GROUP BY Item_Identifier
ORDER BY Total_Sales DESC
LIMIT 5;
"""
run_query(top_items_query, "Top 5 Items")
