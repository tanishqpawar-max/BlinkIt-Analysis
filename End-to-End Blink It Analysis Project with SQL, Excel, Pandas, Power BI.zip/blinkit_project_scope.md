# Blinkit Data Analysis Project Scope

## Project Objective
The goal of this project is to analyze Blinkit's sales performance, customer satisfaction, and inventory distribution to identify key insights and opportunities for optimization using SQL, Excel, Pandas, and Power BI.

## Key Performance Indicators (KPIs)
1. **Total Sales**: Overall revenue generated from all items sold.
2. **Average Sales**: Average revenue per transaction or item.
3. **Number of Items**: Total count of items sold.
4. **Average Rating**: Mean customer rating for items sold.

## Analysis Dimensions
- **Item Type**: Analysis of sales performance across different product categories (e.g., Fruits, Snacks, Household).
- **Outlet Type**: Performance comparison between different store formats (e.g., Supermarket, Grocery Store).
- **Outlet Size**: Impact of store size (Small, Medium, High) on sales.
- **Location Type**: Regional performance analysis (Tier 1, Tier 2, Tier 3 cities).
- **Fat Content**: Customer preference analysis for Low Fat vs. Regular products.

## Technical Stack
- **Excel**: Data cleaning and initial exploration.
- **SQL (SQLite)**: Complex querying and metric calculation.
- **Pandas (Python)**: Data manipulation, EDA, and advanced analytics.
- **Power BI (Simulated)**: Visualization and dashboard reporting (using Matplotlib/Seaborn for visual delivery).

## Data Schema
- `Item_Identifier`: Unique ID for products.
- `Item_Weight`: Weight of the product.
- `Item_Fat_Content`: Fat level (Low Fat/Regular).
- `Item_Visibility`: Percentage of total display area.
- `Item_Type`: Category of the product.
- `Item_MRP`: Maximum Retail Price.
- `Outlet_Identifier`: Unique ID for stores.
- `Outlet_Establishment_Year`: Year the store was opened.
- `Outlet_Size`: Size of the store.
- `Outlet_Location_Type`: City tier.
- `Outlet_Type`: Type of store.
- `Item_Outlet_Sales`: Sales of the product in the particular store.
