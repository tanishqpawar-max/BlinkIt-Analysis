import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
df = pd.read_csv('blinkit_sales_data.csv')

# Set visual style
sns.set_theme(style="whitegrid")
plt.rcParams['figure.figsize'] = (12, 8)

# 1. Total Sales by Item Type (Bar Chart)
plt.figure(figsize=(12, 6))
sales_by_item = df.groupby('Item_Type')['Item_Outlet_Sales'].sum().sort_values(ascending=False)
sns.barplot(x=sales_by_item.values, y=sales_by_item.index, palette='viridis')
plt.title('Total Sales by Item Type', fontsize=16)
plt.xlabel('Total Sales (INR)', fontsize=12)
plt.ylabel('Item Type', fontsize=12)
plt.tight_layout()
plt.savefig('sales_by_item_type.png')
plt.close()

# 2. Sales by Outlet Type (Pie Chart)
plt.figure(figsize=(10, 8))
sales_by_outlet = df.groupby('Outlet_Type')['Item_Outlet_Sales'].sum()
plt.pie(sales_by_outlet, labels=sales_by_outlet.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
plt.title('Sales Distribution by Outlet Type', fontsize=16)
plt.axis('equal')
plt.tight_layout()
plt.savefig('sales_by_outlet_type.png')
plt.close()

# 3. Sales by Location Tier (Donut Chart)
plt.figure(figsize=(10, 8))
sales_by_location = df.groupby('Outlet_Location_Type')['Item_Outlet_Sales'].sum()
plt.pie(sales_by_location, labels=sales_by_location.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('Set2'), wedgeprops=dict(width=0.3))
plt.title('Sales by Location Tier', fontsize=16)
plt.axis('equal')
plt.tight_layout()
plt.savefig('sales_by_location.png')
plt.close()

# 4. Item Fat Content Analysis (Count Plot)
plt.figure(figsize=(8, 6))
sns.countplot(data=df, x='Item_Fat_Content', palette='muted')
plt.title('Product Distribution by Fat Content', fontsize=16)
plt.xlabel('Fat Content', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.tight_layout()
plt.savefig('fat_content_distribution.png')
plt.close()

print("Visualizations created successfully.")
